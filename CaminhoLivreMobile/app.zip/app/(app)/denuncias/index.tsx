import { View, Text } from "react-native";

export default function Denuncias() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Denúncias - CaminhoLivre</Text>
    </View>
  );
}