
import React from "react";

import {
  View,
  Text,
  StyleSheet,
  Pressable,
} from "react-native";

import { router } from "expo-router";

import { useAuth } from "../../src/hooks/useAuth";
import colors from "../../src/styles/colors";

export default function Inicio() {
  const { usuario } = useAuth();

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>
        Olá, {usuario?.nome}!
      </Text>

      <Text style={styles.subtitulo}>
        Bem-vindo ao CaminhoLivre.
      </Text>

      <Text style={styles.descricao}>
        Explore a cidade com mais acessibilidade,
        autonomia e segurança.
      </Text>

      <Pressable
        style={styles.botao}
        onPress={() => router.push("/(app)/perfil")}
      >
        <Text style={styles.textoBotao}>
          Meu perfil
        </Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
    padding: 25,
    justifyContent: "center",
  },
  titulo: {
    fontSize: 28,
    fontWeight: "bold",
    color: colors.primary,
  },
  subtitulo: {
    fontSize: 19,
    color: colors.secondary,
    marginTop: 12,
  },
  descricao: {
    fontSize: 16,
    color: colors.textSecondary,
    marginTop: 18,
    lineHeight: 24,
  },
  botao: {
    backgroundColor: colors.primary,
    padding: 16,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 30,
  },
  textoBotao: {
    color: colors.white,
    fontWeight: "bold",
  },
});
